package databases;

public interface dbDisplay {
	public String DISP_MAL_SONGS = "select title,author,m_name from java where language='Malayalam' ";

	public String DISP_LATEST_SONGS = "select title,author,album_title,m_name from java  where release_date>'31-12-2018'";

	public String DISP_MAX_BUDGET = "select album_title,p_name,genre,budget from java where budget in (select max(budget)";

}
