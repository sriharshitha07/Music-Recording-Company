package databases;

public interface RecordRemover {
	public String DLT_MUSICIAN_BY_ID = "delete from java where id=?";
	public String DLT_SONG_BY_TITLE = "delete from java where title=?";
	public String DLT_BAND_BY_ID = "delete from java where band_id=?";
	public String DLT_ALBUM_BY_ID = "delete from java where album_id=?";
	public String DLT_ALBUM_BY_DATE_RANGE = "delete from java where release_date between ? and ?";

	int deleteMusicianById(String id);

	int deleteSongByTitle(String title);

	int deleteBandById(String id);

	int deleteAlbumById(String id);

	int deleteAlbumByDateRange(String start, String end);

}
